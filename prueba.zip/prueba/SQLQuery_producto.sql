USE [db_restaurante]
GO

/****** Object:  Table [dbo].[producto]    Script Date: 19/01/2020 3:49:54 p. m. ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[producto](
	[nombre] [varchar](100) NOT NULL,
	[precio] [int] NULL,
	[fecha] [datetime] NULL
) ON [PRIMARY]
GO


