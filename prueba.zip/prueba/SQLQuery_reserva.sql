use db_restaurante
create table reservas(
	id_reserva int not null,
	id_cliente int not null,
	numero_comensales int,
	numero_mesa int,
	fecha_de_reserva datetime, 
	)
	alter table reservas 
	add primary key (id_reserva),
	foreign KEY (id_cliente) REFERENCES cliente(id_cliente)