use db_restaurante
create table cliente(
	id_cliente int not null,
	nombre varchar (100) not null,
	apellido varchar (100) not null,
	correo varchar (100) not null,
	telefono varchar (100) not null,
	)
	alter table cliente
	add primary key (id_cliente)