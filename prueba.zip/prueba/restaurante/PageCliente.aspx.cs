﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class PageCliente : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Button1_Click(object sender, EventArgs e)
    {
         try
        {
            clscliente clte = new clscliente(0, "", "", "","","");
            clte.Id_cliente = int.Parse(Tb_id.Text.Trim());
            clte.Nombre = Tb_nombre.Text;
            clte.Apellido = Tb_apellido.Text;
            clte.Correo = Tb_correo.Text;
            clte.Telefono = Tb_telefono.Text;
            clte.Clave = Tb_clave.Text;
            clte.agregar();
            lblestado.Text = "Registro Agregado con exito";
            Tb_id.Text = "";
            Tb_nombre.Text = "";
            Tb_apellido.Text = "";
            Tb_correo.Text = "";
            Tb_telefono.Text = "";
            Tb_clave.Text = "";
        }
        catch {
            lblestado.Text = "Se ha generado una excepción";
        }
    }
    protected void btn_eliminar_Click(object sender, EventArgs e)
    {
        try
        {
            clscliente clte = new clscliente(0, "", "", "","","");
            if (clte.eliminar(int.Parse(Tb_id.Text)))
            {
                lblestado.Text = "El registro se eliminó con exito";
                Tb_id.Text = "";
                Tb_nombre.Text = "";
                Tb_apellido.Text = "";
                Tb_correo.Text = "";
                Tb_telefono.Text = "";
                Tb_clave.Text = "";
            }
            else { lblestado.Text = "El registro No se eliminó"; }
        }
        catch { lblestado.Text = "Se ha generado una excepción"; }
    }

    protected void btn_buscar_Click(object sender, EventArgs e)
    {
        try
        {
            clscliente clte = new clscliente(0, "", "", "","","");
            if (clte.existe(int.Parse(Tb_id.Text)))
            {
                Tb_id.Text = clte.Id_cliente.ToString();
                Tb_apellido.Text = clte.Apellido;
                Tb_nombre.Text = clte.Nombre;
                Tb_correo.Text = clte.Correo;
                Tb_telefono.Text = clte.Telefono;
                Tb_clave.Text = clte.Clave;
                lblestado.Text = "Registro encontrado";
            }
            else
            {
                lblestado.Text = "Registro no Encontrado";
            }
        }
        catch { lblestado.Text = "Se ha generado una excepción"; }
    }
}