﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Reservas : System.Web.UI.Page
{
    public void metodoA(int[] , int pos)
        {
        int sum=0;
            while (i=pos){
                sum=sum+vec[1];
            }
            return sum;	
        }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["usuario"] == null) 
        { 
            lblestado.Text = "el usuario no a iniciado sesion para reservar, por favor inicie sesion en la pestaña inicio ";
            btn_agregar.Visible = false;
            btn_buscar.Visible = false;
            btn_eliminar.Visible = false;
        }
        else { Tb_cliente.Text = (Session["usuario"]).ToString(); }
        if (!IsPostBack) 
        {
            Calendar1.Visible = false;
        }
    }
    protected void btn_buscar_Click(object sender, EventArgs e)
    {
        try
        {
            clsreserva clte = new clsreserva(0, 0, 0, 0, "");
            if (clte.existe(int.Parse(Tb_cliente.Text)))
            {
                Tb_reserva.Text = clte.Id_reserva.ToString();
                Tb_cliente.Text = clte.Id_cliente.ToString();
                Tb_comensales.Text = clte.Numero_comensales.ToString();
                Tb_mesa.Text = clte.Numero_mesa.ToString();
                Tb_fecha.Text = clte.Fecha_de_reserva;
                lblestado.Text = "Registro encontrado";
            }
            else
            {
                lblestado.Text = "Registro no Encontrado";
            }
        }
        catch { lblestado.Text = "Se ha generado una excepción"; }
    }
    protected void btn_agregar_Click(object sender, EventArgs e)
    {
        try
        {
            // validacion para saber si la fecha ya se encuentra reservada
            int numero;
            numero = 0;
            DataView dvSql = (DataView)SqlDataSource1.Select(DataSourceSelectArguments.Empty);

            if (dvSql.Count > 0)
            {
                lblestado.Text = "la fecha ya se encuebtra reservada seleccione una diferente";
            }
            else
            {
                // reserva exitosa
                clsreserva clte = new clsreserva(0, 0, 0, 0, "");
                clte.Id_reserva = int.Parse(Tb_reserva.Text.Trim());
                clte.Id_cliente = int.Parse(Tb_cliente.Text.Trim());
                clte.Numero_comensales = int.Parse(Tb_comensales.Text.Trim());
                clte.Numero_mesa = int.Parse(Tb_mesa.Text.Trim());
                clte.Fecha_de_reserva = Tb_fecha.Text;
                clte.agregar();
                lblestado.Text = "Registro Agregado con exito";
                Tb_reserva.Text = "";
                Tb_cliente.Text = "";
                Tb_comensales.Text = "";
                Tb_mesa.Text = "";
                Tb_fecha.Text = "";
            }
        }
        catch
        {
            lblestado.Text = "Se ha generado una excepción";
        }

    }
    protected void btn_eliminar_Click(object sender, EventArgs e)
    {
        try
        {
            //eliminar reserva
            clscliente clte = new clscliente(0, "", "", "", "","");
            if (clte.eliminar(int.Parse(Tb_cliente.Text)))
            {
                lblestado.Text = "El registro se eliminó con exito";
                Tb_reserva.Text = "";
                Tb_cliente.Text = "";
                Tb_comensales.Text = "";
                Tb_mesa.Text = "";
                Tb_fecha.Text = "";
            }
            else { lblestado.Text = "El registro No se eliminó"; }
        }
        catch { lblestado.Text = "Se ha generado una excepción"; }
    }
    protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
    {
        //boton para activar el calendario y selccionar la fecha
        if (Calendar1.Visible)
        {
            Calendar1.Visible = false;
        }
        else 
        {
            Calendar1.Visible = true;
        }
    }
    protected void Calendar1_SelectionChanged(object sender, EventArgs e)
    {
        Tb_fecha.Text = Calendar1.SelectedDate.ToLongDateString();
        Calendar1.Visible = false;
    }
}