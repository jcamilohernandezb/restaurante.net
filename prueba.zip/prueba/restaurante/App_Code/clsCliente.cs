﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Data;

/// <summary>
/// Clase Cliente
/// </summary>
public class clscliente : clsconexion
{
    string tabla = "cliente"; //nombre de la tabla
    protected string nombre, apellido, correo,telefono,clave;
    protected int id_cliente;

    public clscliente(int idcliente, string nombre, string apellido,string correo, string telefono,string clave)
	{
        this.id_cliente = idcliente;
        this.nombre = nombre;
        this.apellido = apellido;
        this.correo = correo;
        this.telefono = telefono;
        this.clave = clave;
	}
    //metodos para establecer y recuperar datos
    public int Id_cliente
    {
        set { id_cliente = value; }
        get { return id_cliente; }
    }
    public String Nombre
    {
        set { nombre = value; }
        get { return nombre; }
    }
    public String Apellido
    {
        set { apellido = value; }
        get { return apellido; }
    }
    public string Correo 
    {
        set { correo = value; }
        get { return correo; }
    }
    public string Telefono
    {
        set { telefono = value; }
        get { return telefono; }
    }
    public string Clave
    {
        set { clave = value; }
        get { return clave; }
    }

    //metodo agregar registro cliente
    public void agregar()
    {
        conectar(tabla);
        DataRow fila;
        fila = Data.Tables[tabla].NewRow();
        fila["id_cliente"] = Id_cliente;
        fila["nombre"] = Nombre;
        fila["apellido"] = Apellido;
        fila["correo"] = Correo;
        fila["telefono"] = Telefono;
        fila["clave"] = Clave;
        Data.Tables[tabla].Rows.Add(fila);
        AdaptadorDatos.Update(Data, tabla);
    }

    public bool eliminar(int valor)
    {
        conectar(tabla);
        DataRow fila;
        int x = Data.Tables[tabla].Rows.Count - 1;
        for (int i = 0; i <= x; i++)
        {
            fila = Data.Tables[tabla].Rows[i];

            if (int.Parse(fila["id_cliente"].ToString()) == valor)
            {
                fila = Data.Tables[tabla].Rows[i];
                fila.Delete();
                DataTable tablaborrados;
                tablaborrados = Data.Tables[tabla].GetChanges(DataRowState.Deleted);
                AdaptadorDatos.Update(tablaborrados);
                Data.Tables[tabla].AcceptChanges();
                return true;
            }
        } return false;
    }

    public bool existe(int valor)
    {
        conectar(tabla);
        DataRow fila;
        int x = Data.Tables[tabla].Rows.Count - 1;
        for (int i = 0; i <= x; i++)
        {
            fila = Data.Tables[tabla].Rows[i];
            if (int.Parse(fila["id_cliente"].ToString()) == valor)
            {
                Id_cliente = int.Parse(fila["id_cliente"].ToString());
                Nombre = fila["nombre"].ToString();
                Apellido = fila["apellido"].ToString();
                Correo = fila["correo"].ToString();
                Telefono = fila["telefono"].ToString();
                Clave = fila["clave"].ToString();
                return true;
            }
        } return false;
    }
}