﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Data;

/// <summary>
/// Descripción breve de clsreserva
/// </summary>
public class clsreserva : clsconexion
{
    string tabla = "reservas"; //nombre de la tabla
    protected int id_reserva, id_cliente, numero_comensales, numero_mesa;
    protected string fecha_de_reserva;

    public clsreserva(int idreserva, int idcliente, int numerocomensales, int numeromesa,string fechadereserva)
	{
        this.id_reserva = idreserva;
        this.id_cliente = idcliente;
        this.numero_comensales = numerocomensales;
        this.numero_mesa = numeromesa;
        this.fecha_de_reserva = fechadereserva;
	}


    //metodos para establecer y recuperar datos
    public int Id_reserva
    {
        set { id_reserva = value; }
        get { return id_reserva; }
    }
    public int Id_cliente
    {
        set { id_cliente = value; }
        get { return id_cliente; }
    }
    public int Numero_comensales
    {
        set { numero_comensales = value; }
        get { return numero_comensales; }
    }
    public int Numero_mesa
    {
        set { numero_mesa = value; }
        get { return numero_mesa; }
    }
    public string Fecha_de_reserva
    {
        set { fecha_de_reserva = value; }
        get { return fecha_de_reserva; }
    }

    //metodo agregar registro cliente
    public void agregar()
    {
        conectar(tabla);
        DataRow fila;
        fila = Data.Tables[tabla].NewRow();
        fila["id_reserva"] = Id_reserva;
        fila["id_cliente"] = id_cliente;
        fila["numero_comensales"] = Numero_comensales;
        fila["numero_mesa"] = Numero_mesa;
        fila["fecha_de_reserva"] = Fecha_de_reserva;

        Data.Tables[tabla].Rows.Add(fila);
        AdaptadorDatos.Update(Data, tabla);
    }

    public bool eliminar(int valor)
    {
        conectar(tabla);
        DataRow fila;
        int x = Data.Tables[tabla].Rows.Count - 1;
        for (int i = 0; i <= x; i++)
        {
            fila = Data.Tables[tabla].Rows[i];

            if (int.Parse(fila["id_cliente"].ToString()) == valor)
            {
                fila = Data.Tables[tabla].Rows[i];
                fila.Delete();
                DataTable tablaborrados;
                tablaborrados = Data.Tables[tabla].GetChanges(DataRowState.Deleted);
                AdaptadorDatos.Update(tablaborrados);
                Data.Tables[tabla].AcceptChanges();
                return true;
            }
        } return false;
    }

    public bool existe(int valor)
    {
        conectar(tabla);
        DataRow fila;
        int x = Data.Tables[tabla].Rows.Count - 1;
        for (int i = 0; i <= x; i++)
        {
            fila = Data.Tables[tabla].Rows[i];
            if (int.Parse(fila["id_cliente"].ToString()) == valor)
            {
                Id_reserva = int.Parse(fila["id_reserva"].ToString());
                Id_cliente = int.Parse(fila["id_cliente"].ToString());
                Numero_comensales = int.Parse(fila["numero_comensales"].ToString());
                Numero_mesa = int.Parse(fila["numero_mesa"].ToString());
                Fecha_de_reserva = fila["fecha_de_reserva"].ToString();
                return true;
            }
        } return false;
    }
}